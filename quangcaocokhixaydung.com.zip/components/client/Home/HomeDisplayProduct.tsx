import React from "react";

const HomeDisplayProduct = () => {
  return <div>HomeDisplayProduct</div>;
};

export default HomeDisplayProduct;
